document.getElementById('loginForm').addEventListener('submit', function(event) {
  event.preventDefault();
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  if (username === "student" && password === "satprep") {
    window.location.href = "test.html";
  } else {
    alert("Неправильное имя пользователя или пароль.");
  }
});
